# 📋 QUICK REFERENCE: TRI SPREADSHEET POPULATION

**Date:** July 15, 2026  
**Status:** Research complete; ready to enter into Excel  

---

## 🎯 COPY-PASTE READY DATA

Open your `DIY_DNA_Synthesis_TRI_Spreadsheet.xlsx` file and use these values for the **TRI_Raw_Data** tab.

---

## OPENDS (INKJET)

| Field | Value | Confidence | Source |
|-------|-------|------------|--------|
| **Name** | OpenIDS (Inkjet) | HIGH | Kim et al. 2024, 2025 |
| **TRL** | 5 | HIGH | Kim et al. 2024, 2025 |
| **Capital_Cost** | 19900 | HIGH | Kim et al. 2024 |
| **Per_Seq_Cost** | 12 | MEDIUM | Sigma catalog + synthesis.cc |
| **Expertise_Required** | 6 | HIGH | Kim et al. 2024, 2025 |
| **Time_to_First_Synthesis** | 5 | MEDIUM | Estimated from literature |
| **Max_Sequence_Length** | 100 | HIGH | Kim et al. 2024, 2025 |
| **Synthesis_Yield** | 98 | HIGH | Kim et al. 2024 (propylene carbonate) |
| **Detectability** | 4 | MEDIUM | Policy analysis + IFP 2024 |
| **Supply_Chain_Vulnerability** | 7 | MEDIUM | Xaar 128 printhead sourcing analysis |
| **Note** | 5-printhead version; includes 3D-printed parts, Xaar 128, Arduino, Raspberry Pi | - | - |

---

## OPENDS 2 (INKJET v2)

| Field | Value | Confidence | Source |
|-------|-------|------------|--------|
| **Name** | OpenIDS2 (Inkjet v2) | HIGH | Kim et al. 2025 |
| **TRL** | 5 | HIGH | Kim et al. 2025 |
| **Capital_Cost** | 20000 | HIGH | Kim et al. 2025 |
| **Per_Seq_Cost** | 12 | MEDIUM | Same as v1 |
| **Expertise_Required** | 6 | HIGH | Kim et al. 2025 |
| **Time_to_First_Synthesis** | 5 | MEDIUM | Estimated from literature |
| **Max_Sequence_Length** | 150 | HIGH | Kim et al. 2025 |
| **Synthesis_Yield** | 98 | HIGH | Kim et al. 2025 |
| **Detectability** | 4 | MEDIUM | Same as v1 |
| **Supply_Chain_Vulnerability** | 7 | MEDIUM | Same as v1 |
| **Note** | Reduced volume (1/3 of v1); integrated PCB; peristaltic pump; improved accessibility | - | - |

---

## ELECTROCHEMICAL

| Field | Value | Confidence | Source |
|-------|-------|------------|--------|
| **Name** | Electrochemical | MEDIUM | Xu et al. 2021 |
| **TRL** | 3 | HIGH | Xu et al. 2021 |
| **Capital_Cost** | 10000 | MEDIUM | Xu et al. 2021 + AliExpress |
| **Per_Seq_Cost** | 5 | MEDIUM | Estimated from reagent costs |
| **Expertise_Required** | 6 | MEDIUM | Xu et al. 2021 |
| **Time_to_First_Synthesis** | 3 | MEDIUM | Estimated from literature |
| **Max_Sequence_Length** | 200 | MEDIUM | Xu et al. 2021 |
| **Synthesis_Yield** | 87 | MEDIUM | Xu et al. 2021 (conservative) |
| **Detectability** | 9 | MEDIUM-HIGH | IFP 2024 + policy analysis |
| **Supply_Chain_Vulnerability** | 9 | HIGH | IFP 2024 supply chain analysis |
| **Note** | Au/Pd electrodes; SlipChip microfluidics; aqueous chemistry; CHI potentiostat or Arduino variant | - | - |

---

## ENZYMATIC (ANSA SERVICE)

| Field | Value | Confidence | Source |
|-------|-------|------------|--------|
| **Name** | Enzymatic (Ansa Service) | HIGH | Ansa 2024-2025 |
| **TRL** | 6 | HIGH | Ansa website (commercial now) |
| **Capital_Cost** | 0 | HIGH | Service-based model |
| **Per_Seq_Cost** | 10 | HIGH | Ansa website: $0.28-$0.38 per bp (10kb = ~10 cents) |
| **Expertise_Required** | 7 | HIGH | Just place an order; standard biotech |
| **Time_to_First_Synthesis** | 2 | HIGH | Ansa: <25 business days (typically 10-14 days) |
| **Max_Sequence_Length** | 50000 | HIGH | Ansa 50kb product (May 2025) |
| **Synthesis_Yield** | 97 | HIGH | Ansa marketing material |
| **Detectability** | 6 | HIGH | Service-based, centralized, screened |
| **Supply_Chain_Vulnerability** | 4 | HIGH | Ansa is monopoly provider for enzymatic service |
| **Note** | TdT-dNTP conjugate method; fully aqueous; 99.9% cycle efficiency; up to 50kb direct synthesis; on-time guarantee | - | - |

---

## ENZYMATIC (DNA SCRIPT BENCHTOP)

| Field | Value | Confidence | Source |
|-------|-------|------------|--------|
| **Name** | Enzymatic (DNA Script Benchtop) | HIGH | DNA Script 2021-2025 |
| **TRL** | 6 | HIGH | DNA Script (commercial now) |
| **Capital_Cost** | 450000 | HIGH | Industry estimates; DNA Script pricing |
| **Per_Seq_Cost** | 8 | MEDIUM | Estimated from kit costs (~$2-3K per 96 reactions) |
| **Expertise_Required** | 2 | HIGH | User-friendly; minimal training |
| **Time_to_First_Synthesis** | 1 | HIGH | 6 hours (20-mers) to 13 hours (60-mers) |
| **Max_Sequence_Length** | 120 | HIGH | DNA Script Syntax specs (hi-fidelity kit) |
| **Synthesis_Yield** | 96 | HIGH | DNA Script marketing material |
| **Detectability** | 6 | HIGH | Benchtop instrument; commercial, screened |
| **Supply_Chain_Vulnerability** | 3 | HIGH | DNA Script supply contracts |
| **Note** | SYNTAX System benchtop; enzymatic DNA synthesis; 96-oligo parallel; no harsh solvents; same-day results; not DIY-friendly | - | - |

---

## COMMERCIAL BENCHTOP (REFERENCE)

| Field | Value | Confidence | Source |
|-------|-------|------------|--------|
| **Name** | Commercial Benchtop (Chemical) | HIGH | Industry standard |
| **TRL** | 7 | HIGH | Established technology |
| **Capital_Cost** | 120000 | HIGH | Industry average (MerMade 192E ~$150K) |
| **Per_Seq_Cost** | 0.05 | HIGH | Commercial production costs |
| **Expertise_Required** | 2 | HIGH | Standard lab equipment |
| **Time_to_First_Synthesis** | 1 | HIGH | Same-day synthesis |
| **Max_Sequence_Length** | 1000 | HIGH | Well-established; 1+ kb common |
| **Synthesis_Yield** | 99 | HIGH | Phosphoramidite chemistry (mature) |
| **Detectability** | 1 | HIGH | Entirely subject to screening |
| **Supply_Chain_Vulnerability** | 1 | HIGH | Regulated benchtop market |
| **Note** | Baseline for comparison; phosphoramidite chemistry; high waste; screening-compliant | - | - |

---

## COMMERCIAL PROVIDER (IDTDNA, TWIST, GENSCRIPT)

| Field | Value | Confidence | Source |
|-------|-------|------------|--------|
| **Name** | Commercial Provider (Synthesis) | HIGH | Industry standard |
| **TRL** | 8 | HIGH | Mature, established |
| **Capital_Cost** | 0 | HIGH | Service-based |
| **Per_Seq_Cost** | 0.05 | HIGH | Public pricing |
| **Expertise_Required** | 10 | HIGH | Just place an order online |
| **Time_to_First_Synthesis** | 0.5 | HIGH | 24-48 hour turnaround |
| **Max_Sequence_Length** | 10000 | HIGH | Common limit; longer possible |
| **Synthesis_Yield** | 99 | HIGH | Mature chemistry |
| **Detectability** | 0.2 | HIGH | 100% screened (OSTP/IGSC) |
| **Supply_Chain_Vulnerability** | 0.5 | HIGH | Centralized, regulated oligopoly |
| **Note** | Baseline governance model; complete OSTP/IGSC screening; established companies; quality assured | - | - |

---

## 📊 HOW TO ENTER INTO EXCEL

1. Open `DIY_DNA_Synthesis_TRI_Spreadsheet.xlsx`
2. Go to **TRI_Raw_Data** tab
3. For each approach above:
   - Copy the values from the table
   - Paste into corresponding columns
   - Set **Confidence** column to: HIGH / MEDIUM / LOW
   - Add source URL/DOI in **Source** column

4. Go to **Data_Sources** tab
   - Add all DOIs and publication details
   - Include confidence level for each cell

5. **TRI_Derived** tab will auto-calculate once raw data is entered

---

## ✅ VALIDATION CHECKLIST

Before finalizing:

- [ ] All 6 approaches entered (OpenIDS, OpenIDS2, Electrochemical, Ansa, DNA Script, Commercial ref, Provider)
- [ ] All 9 dimensions populated for each approach
- [ ] Confidence levels assigned (HIGH/MEDIUM/LOW)
- [ ] Sources cited in Data_Sources tab
- [ ] Derived indices calculated (check formulas in TRI_Derived)
- [ ] No blank cells (fill with "Unknown" or "TBD" if needed)
- [ ] Values make sense (e.g., per-oligo cost < capital cost)
- [ ] Expert review by Rassin scheduled (week of July 15)

---

## 💡 NOTES FOR RASSIN MEETING

When you meet with Rassin to review the spreadsheet:

**Key findings to highlight:**
1. Electrochemical is the critical concern (low cost, invisible, uncontrollable)
2. OpenIDS has a control point (Xaar 128 printhead monitoring)
3. Enzymatic remains service-centric (enzyme engineering barrier)
4. TRL 3 → TRL 5 progression is rapid (by 2028)
5. Cost convergence is happening (~$10K for electrochemical)

**Data quality issues to discuss:**
- Electrochemical: Limited published cost data; confidence MEDIUM
- Enzymatic DIY: Very difficult, estimated from literature
- Detectability: Based on policy assessment, not empirical measurement

---

## 📝 RESEARCH STATUS

**Completed:**
- ✅ OpenIDS: HIGH confidence (2 peer-reviewed papers + GitHub)
- ✅ Electrochemical: MEDIUM confidence (1 paper + IFP analysis)
- ✅ Enzymatic (Ansa): HIGH confidence (company website + market reports)
- ✅ Enzymatic (DNA Script): HIGH confidence (company specs + press releases)

**Still TBD (Phase 2):**
- [ ] Expert interviews (Kim/Bang lab, Ansa CEO)
- [ ] DIY community survey (DIYbio.org)
- [ ] Updated cost quotes (Sigma, ChemGenes, AliExpress)
- [ ] Expanded detectability assessment

---

**Data compiled by:** Olena Didenko  
**Date:** July 15, 2026  
**Time to enter into spreadsheet:** ~30 minutes  

